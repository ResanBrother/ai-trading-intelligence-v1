# AI Trading Intelligence V1

Prototype untuk riset/paper trading. Tidak terhubung ke broker dan tidak mengeksekusi order.

## 1. Install
Python 3.11+ disarankan.

```bash
pip install -r requirements.txt
```

## 2. Jalankan
```bash
streamlit run app.py
```

## 3. Data CSV
Kolom wajib:
- open
- high
- low
- close

Opsional:
- timestamp
- volume

Contoh:
timestamp,open,high,low,close,volume
2026-01-01 00:00,1.1000,1.1050,1.0980,1.1030,1000

## 4. API key
Masukkan OpenAI API key di sidebar saat aplikasi berjalan.
Jangan masukkan API key ke file kode atau commit ke Git.

## V1 architecture
CSV -> indicator engine -> dashboard -> OpenAI reasoning -> research report.

## Batasan
V1 belum melakukan backtesting walk-forward, database, multi-timeframe ingestion,
news ingestion, atau broker integration. Tambahkan modul tersebut setelah V1
berhasil berjalan dan divalidasi dengan paper data.
