
import os
import pandas as pd
import numpy as np
import streamlit as st
from openai import OpenAI

st.set_page_config(page_title="AI Trading Intelligence V1", layout="wide")

SYSTEM_PROMPT = """
You are Trading Intelligence Analyst V1.

Purpose: educational research and paper-trading analysis only.
Never execute trades. Never connect to a broker. Never claim certainty.

Rules:
1. Use only the market data supplied in the prompt.
2. Clearly separate FACT, INFERENCE, and ASSUMPTION.
3. If required data is missing, say INSUFFICIENT DATA.
4. Analyze market regime, multi-timeframe structure when available,
   trend, momentum, volatility, support/resistance, and contradictions.
5. Generate three scenarios: bullish, bearish, neutral.
6. Actively argue against your primary thesis.
7. A NO TRADE / WAIT result is valid and preferred to a forced setup.
8. Do not invent prices, news, indicators, or live market access.
9. Do not provide instructions for executing real-money trades.
10. Any entry/invalidation/target discussion must be clearly labeled
    hypothetical and for paper trading/research.

Output:
# MARKET INTELLIGENCE REPORT
## Data Quality
## Market Regime
## Structure
## Indicators
## Bullish Scenario
## Bearish Scenario
## Neutral Scenario
## Confluence Assessment
## Hypothetical Research Plan
## Devil's Advocate
## Final Status
## What Would Change My Mind?
"""

def rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = (-delta.clip(upper=0)).rolling(period).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def atr(df, period=14):
    prev_close = df["close"].shift(1)
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs()
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def add_indicators(df):
    df = df.copy()
    for p in [20, 50, 200]:
        df[f"ema{p}"] = df["close"].ewm(span=p, adjust=False).mean()
    df["rsi14"] = rsi(df["close"])
    df["atr14"] = atr(df)
    ema12 = df["close"].ewm(span=12, adjust=False).mean()
    ema26 = df["close"].ewm(span=26, adjust=False).mean()
    df["macd"] = ema12 - ema26
    df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()
    return df

def validate_csv(df):
    required = {"open", "high", "low", "close"}
    missing = required - set(df.columns.str.lower())
    return missing

st.title("AI Trading Intelligence — V1")
st.caption("Educational research / paper-trading prototype. No broker connection or automatic execution.")

with st.sidebar:
    st.header("Settings")
    api_key = st.text_input("OpenAI API key", type="password",
                            value=os.getenv("OPENAI_API_KEY", ""))
    model = st.text_input("Model", value="gpt-5.6")
    symbol = st.text_input("Symbol", value="EUR/USD")
    timeframe = st.text_input("Timeframe", value="1H")

uploaded = st.file_uploader("Upload CSV OHLC data", type=["csv"])

st.markdown("""
**CSV minimal format:** `timestamp,open,high,low,close,volume`  
`timestamp` and `volume` are optional. Prices must be numeric.
""")

if uploaded:
    raw = pd.read_csv(uploaded)
    raw.columns = [c.strip().lower() for c in raw.columns]

    missing = validate_csv(raw)
    if missing:
        st.error(f"Missing required columns: {', '.join(sorted(missing))}")
        st.stop()

    for c in ["open", "high", "low", "close"]:
        raw[c] = pd.to_numeric(raw[c], errors="coerce")
    raw = raw.dropna(subset=["open", "high", "low", "close"]).reset_index(drop=True)

    if len(raw) < 50:
        st.warning("V1 needs at least 50 rows for a meaningful research snapshot.")
    df = add_indicators(raw)

    latest = df.iloc[-1]
    st.subheader(f"{symbol} — {timeframe}")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Last Close", f"{latest['close']:.6g}")
    c2.metric("EMA20", f"{latest['ema20']:.6g}")
    c3.metric("RSI14", f"{latest['rsi14']:.2f}" if pd.notna(latest['rsi14']) else "N/A")
    c4.metric("ATR14", f"{latest['atr14']:.6g}" if pd.notna(latest['atr14']) else "N/A")

    st.subheader("Price")
    chart_df = df.copy()
    if "timestamp" in chart_df.columns:
        chart_df["timestamp"] = pd.to_datetime(chart_df["timestamp"], errors="coerce")
        chart_df = chart_df.set_index("timestamp")
    else:
        chart_df.index = range(len(chart_df))
    st.line_chart(chart_df[["close", "ema20", "ema50", "ema200"]].tail(300))

    st.subheader("AI Analysis")
    if st.button("Analyze dataset"):
        if not api_key:
            st.error("Enter an OpenAI API key in the sidebar.")
            st.stop()

        client = OpenAI(api_key=api_key)

        cols = ["open", "high", "low", "close", "ema20", "ema50", "ema200",
                "rsi14", "atr14", "macd", "macd_signal"]
        snapshot = df[cols].tail(120).round(6).to_csv(index=False)

        user_prompt = f"""
Instrument: {symbol}
Timeframe: {timeframe}

You have the following OHLC-derived dataset. Analyze ONLY this data.
No live data and no external news are available.

DATA:
{snapshot}

Produce the required MARKET INTELLIGENCE REPORT.
Do not fabricate missing information.
"""

        with st.spinner("Running analysis..."):
            response = client.responses.create(
                model=model,
                instructions=SYSTEM_PROMPT,
                input=user_prompt,
            )
        st.markdown(response.output_text)

else:
    st.info("Upload an OHLC CSV to begin.")
    st.markdown("""
### V1 includes
- CSV OHLC ingestion
- EMA 20/50/200
- RSI 14
- ATR 14
- MACD
- Price/indicator dashboard
- AI market-regime and scenario analysis
- Devil's-advocate review
- Paper-trading/research-only output

### Not included
- Broker connection
- Automatic order execution
- Real-money trading
- Guaranteed predictions
""")
